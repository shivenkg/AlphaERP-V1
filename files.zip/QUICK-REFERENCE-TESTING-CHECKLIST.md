# HVAC Dashboard - Quick Reference Testing Checklist

## Pre-Testing Setup (Day 1)

### Environment Preparation
```
□ Access to test environment (staging/dev)
□ Test database loaded with sample data
□ VPN connected (if required)
□ Test user accounts created (10+ accounts across roles)
□ Email service configured (for verification emails)
□ API endpoints accessible and documented
□ Third-party integrations activated
□ Monitoring tools deployed
□ Screenshots/recording tools ready
□ Browser cache cleared, extensions disabled
□ Mobile devices ready (iOS & Android)
```

### Tools Installation
```
□ Burp Suite Community (security testing)
□ Apache JMeter (load testing)
□ Postman (API testing)
□ Chrome DevTools (already built-in)
□ Screenshot tools (Snagit, Greenshot)
□ Video recording (OBS, ScreenFlow)
```

### Test Data Preparation
```
□ Sample leads: 20 records (various statuses)
□ Sample customers: 15 records
□ Sample quotes: 25 records
□ Sample projects: 20 records
□ Sample inventory: 100 SKUs
□ Test credit cards (Stripe/payment testing)
□ Test phone numbers for SMS
□ Test emails (unique, deliverable)
```

---

## Testing Checklist by Type

### FUNCTIONAL TESTING CHECKLIST (Weeks 1-2)

#### Dashboard Module
```
□ Dashboard loads in < 3 seconds
□ All 5 metric cards visible
□ Dark mode toggle works & persists
□ Refresh button updates data
□ Metric cards show accurate data
□ No console errors
□ Responsive on mobile/tablet
□ Cards clickable (drill-down works)
```

#### Navigation
```
□ All 8 sidebar menu items clickable
□ Correct page loads for each menu item
□ URL updates correctly
□ Active menu item highlighted
□ Breadcrumb navigation works
□ Back button works
□ Search functionality filters items
□ Mobile menu (hamburger) works
```

#### CRUD Operations - For Each Module (Leads, Quotes, Inventory, Projects)
```
CREATE:
  □ "Add [Entity]" button visible
  □ Form opens with all required fields
  □ Form submits successfully
  □ Success notification shown
  □ New item appears in list immediately
  □ Database record created
  □ Auto-ID generated correctly

READ:
  □ List view shows all items
  □ Click item opens detail view
  □ All fields display correctly
  □ No data truncation
  □ Related items linked
  □ Pagination works (if applicable)
  □ Search finds items
  □ Filters work correctly

UPDATE:
  □ Edit button available
  □ Edit form pre-populated
  □ Can modify single field
  □ Can modify multiple fields
  □ Save button works
  □ Changes reflected immediately
  □ Database updated
  □ Audit trail shows change
  □ Notification shows success

DELETE:
  □ Delete button/icon available
  □ Confirmation dialog shown
  □ Confirmation describes action
  □ Can cancel deletion
  □ Deletion removes item from list
  □ Database record removed
  □ Notification shows success
  □ Soft delete (if applicable): archive shown
```

#### Form Validation
```
□ Required fields marked
□ Empty required field shows error on submit
□ Error message clear and helpful
□ Email validation works (invalid rejected)
□ Number fields reject letters
□ Date fields only accept dates
□ Min/max validations enforced
□ Pattern validation works (phone, zip)
□ Field focus on error
□ Error clears when corrected
□ No client errors (console clean)
```

#### Search & Filtering
```
□ Search finds matching items
□ Search is case-insensitive
□ Partial matches work
□ Special characters handled
□ Results update in real-time
□ Filter dropdowns work
□ Multiple filters combine (AND logic)
□ Filters persist when pagination
□ Clear filters button works
□ No results message shown when empty
```

---

### SECURITY TESTING CHECKLIST (Week 1)

#### Authentication & Authorization
```
□ Login required for all pages
□ Invalid login rejected
□ Session timeout after 30 minutes
□ Logout clears session
□ Can't access other user's data
□ Can't access admin features (non-admin)
□ Password reset token expires in 30 minutes
□ Password reset token single-use
□ Account lockout after 5 failed logins
□ 2FA/MFA working (if enabled)
```

#### OWASP Top 10 Tests
```
A01 - Broken Access Control:
  □ Test privilege escalation
  □ Test unauthorized data access
  □ Test role-based access
  □ Test path traversal (try ../ in URLs)

A02 - Cryptographic Failures:
  □ All traffic over HTTPS
  □ TLS 1.2 or higher
  □ Certificate valid
  □ Passwords hashed (not plain text)
  □ API tokens encrypted

A03 - Injection:
  □ SQL injection blocked (test: ' OR '1'='1)
  □ NoSQL injection blocked
  □ Command injection blocked
  □ XSS blocked (test: <script>alert('XSS')</script>)
  □ Path traversal blocked

A04 - Insecure Design:
  □ Authentication on all endpoints
  □ Weak password policy NOT allowed
  □ Rate limiting implemented

A05 - Broken Authentication:
  □ Session validation working
  □ Session hijacking not possible
  □ Password reset secure
  □ Account lockout working
  □ No brute force attacks possible

A07 - Authentication Failures:
  □ 2FA/MFA working (if enabled)
  □ Session timeout working
  □ Can't reuse old password

A09 - Logging & Monitoring:
  □ No passwords in logs
  □ No tokens in logs
  □ Audit trail complete
  □ Suspicious activity logged
```

#### Data Protection (GDPR)
```
□ PII masked in UI (SSN, CC)
□ Data export works (GDPR right)
□ Data deletion works (GDPR right)
□ Consent management active
□ Privacy policy present
□ Cookie consent shown
□ User can opt-out of marketing
□ Data not shared with third parties (without consent)
```

---

### PERFORMANCE TESTING CHECKLIST (Week 2)

#### Baseline Performance (1 User)
```
□ Dashboard loads: < 3 seconds
□ First page paint: < 1 second
□ Largest paint: < 2.5 seconds
□ Time to interactive: < 3.5 seconds
□ API response: < 200ms
□ Search response: < 1 second
□ Report generation: < 30 seconds
```

#### Load Testing (50 Concurrent Users)
```
□ 90% of requests respond in < 3 seconds
□ Error rate < 1%
□ No timeouts
□ No memory leaks
□ Database connections released
□ No UI lag or unresponsiveness
```

#### Peak Load Testing (500 Concurrent Users)
```
□ 95% of requests respond in < 5 seconds
□ Error rate < 5%
□ System doesn't crash
□ Graceful degradation shown
□ "Service busy" message if needed
□ No data loss
□ Server CPU < 80%
□ Server memory < 85%
```

#### Endurance Test (24-hour)
```
□ Memory stable (no leaks)
□ Response time consistent
□ Error rate < 1%
□ Database connections stable
□ No timeout errors
□ System remains stable at end
```

---

### COMPATIBILITY TESTING CHECKLIST (Week 1-2)

#### Browsers (Test Latest & Latest-1 versions)
```
Chrome:
  □ Desktop 1920×1080
  □ Tablet 768×1024
  □ Mobile 375×812
  
Firefox:
  □ Desktop 1920×1080
  
Safari:
  □ Mac Desktop 1920×1080
  □ iPad 1024×768
  □ iPhone latest models
  
Edge:
  □ Desktop 1920×1080
```

#### For Each Browser/Device:
```
□ Page loads completely
□ Layout not broken
□ Sidebar accessible
□ Navigation works
□ Buttons clickable
□ Forms functional
□ Text readable (not too small)
□ Images display correctly
□ No horizontal scrolling (mobile)
□ Touch targets adequate (mobile)
□ Keyboard navigation works
□ Dark mode works
□ No console errors
□ Performance acceptable
```

---

### UAT TESTING CHECKLIST (Week 2-3)

#### Business Workflows to Verify
```
□ Lead to Quote workflow
  - Lead created/imported
  - Quote auto-populated from lead
  - Quote calculations accurate
  - Customer receives quote email
  - Quote shows correct total
  - Quote can be approved by customer

□ Quote to Project conversion
  - Click "Convert to Project"
  - Project created automatically
  - All quote details transferred
  - Work order generated
  - Technician assigned
  - Customer notified

□ Project Execution
  - Technician sees job in mobile app
  - Can update status: "In Progress"
  - Can attach photos
  - Can add notes
  - Status visible to manager in real-time
  - Customer gets status updates

□ Inventory Management
  - Add SKU works
  - Stock level visible
  - Can reserve parts
  - Low stock alerts trigger
  - Auto-reorder when below threshold
  - Stock calculation accurate

□ Financial Reporting
  - Revenue report accurate (verify math)
  - Month-to-month comparison correct
  - Year-to-date total accurate
  - Tax calculations correct
  - Export to PDF works
  - Charts display correctly

□ User Management
  - Admin can create users
  - Roles assigned correctly
  - Permissions enforced
  - Users can reset password
  - Inactive users disabled
  - Audit trail shows changes
```

#### Business User Sign-Offs
```
For Each Workflow:
  □ Business owner reviews workflow
  □ Confirms accuracy and completeness
  □ Confirms meets business requirements
  □ Confirms acceptable performance
  □ Confirms no data loss
  □ Signs off: "Ready for production"
```

---

### API TESTING CHECKLIST

#### For Each Endpoint:
```
GET /api/[resource]
  □ Returns 200 OK
  □ Returns correct data
  □ Filtering works
  □ Pagination works
  □ Sorting works
  □ Accepts valid query params
  □ Rejects invalid params (400 Bad Request)
  □ Requires authentication (401 if not auth)
  □ Enforces authorization (403 if not permitted)
  □ Response time < 200ms

POST /api/[resource]
  □ Creates new record
  □ Returns 201 Created
  □ Returns created object with ID
  □ Database record created
  □ Audit trail logged
  □ Required fields validated
  □ Rejects invalid data (400)
  □ Rejects duplicate (409 if applicable)
  □ Requires authentication

PUT/PATCH /api/[resource]/{id}
  □ Updates record
  □ Returns 200 OK
  □ Returns updated object
  □ Database updated
  □ Partial updates work (PATCH)
  □ Can't update other user's data
  □ Audit trail logged

DELETE /api/[resource]/{id}
  □ Deletes record (or soft delete)
  □ Returns 204 No Content
  □ Record removed from list
  □ Database updated
  □ Can't delete other user's data
  □ Audit trail logged

Error Handling:
  □ 400 Bad Request: Invalid input
  □ 401 Unauthorized: No auth
  □ 403 Forbidden: No permission
  □ 404 Not Found: Resource doesn't exist
  □ 409 Conflict: Duplicate data
  □ 500 Server Error: Rare, server logs available
```

---

## Defect Tracking Quick Guide

### When to Log a Defect
```
Log defect when:
  □ Feature doesn't work as specified
  □ Feature works, but incorrectly
  □ Performance below acceptable
  □ Security vulnerability found
  □ Data loss occurs
  □ Crash or exception
  □ Error message unclear
  □ UI broken/misaligned
```

### Defect Report Template
```
Title: [Clear, concise description]
  Good: "Dark mode toggle doesn't persist after refresh"
  Bad: "Bug in dashboard"

Steps to Reproduce:
  1. [Exact step 1]
  2. [Exact step 2]
  3. [Exact step 3]

Expected Result:
  [What should happen]

Actual Result:
  [What actually happened]

Severity:
  □ CRITICAL (app crash, data loss, security)
  □ HIGH (major feature broken)
  □ MEDIUM (feature broken but workaround exists)
  □ LOW (minor UI issue)

Environment:
  OS: [Windows 11 / macOS / Linux]
  Browser: [Chrome 121.0]
  Version: [v2.3.1]
  Instance: [Dev / Staging]

Screenshots/Video:
  [Attach evidence]
```

### Defect Severity Definitions
```
CRITICAL - Must fix before release:
  • App crashes
  • Data loss
  • Security vulnerability
  • Core feature completely broken
  • Security breach
  • Data corruption

HIGH - Fix ASAP:
  • Major feature not working
  • Affects multiple users
  • No workaround available
  • Frequent occurrence

MEDIUM - Fix soon:
  • Feature works incorrectly
  • Workaround available
  • Less frequently used feature

LOW - Fix when time allows:
  • Minor UI issue
  • Typo or formatting
  • One-off occurrence
  • Cosmetic only
```

---

## Daily Testing Checklist

### Morning (Start of Day)
```
□ Check status of open defects
□ Review yesterday's test execution
□ Confirm test environment accessible
□ Verify test data available
□ Check for overnight issues/alerts
□ Review today's test plan
□ Any blockers or dependencies?
```

### During Testing
```
□ Follow test cases exactly (don't skip steps)
□ Document actual results (not expected)
□ Take screenshots of issues
□ Note time taken for each test
□ Report blockers immediately
□ Verify defects are reproducible before logging
□ Test both happy path and error scenarios
```

### End of Day
```
□ Update test status spreadsheet
□ Close all open defects/findings
□ Provide daily summary report
□ Document blockers for next day
□ Back up any test results/evidence
□ Update test metrics
□ Communicate status to team
```

---

## Key Performance Indicators (KPIs) to Track

### Test Execution
```
Total Test Cases: ___
Executed: ___ (%)
Passed: ___ (%)
Failed: ___ (%)
Blocked: ___ (%)
Pending: ___ (%)

Target: > 95% pass rate before release
```

### Defect Metrics
```
Total Defects Found: ___
  Critical: ___ (target: 0 at release)
  High: ___ (target: 0 at release)
  Medium: ___ (target: < 5 at release)
  Low: ___ (no limit)

Resolved: ___ (%)
Open: ___ (%)
Deferred: ___ (%)
```

### Quality Metrics
```
Code Coverage: ___% (target: > 80%)
Test Coverage: ___% (target: > 80%)
Security Issues: ___
Performance: ___ response time (target: < 3s)
Uptime: ___%
```

---

## Communication Template

### Daily Status Report
```
TESTING DAILY REPORT
Date: YYYY-MM-DD
Prepared by: [Name]

Overall Status: 🟢 GREEN / 🟡 YELLOW / 🔴 RED

Progress:
  Tests Executed: 45/100 (45%)
  Tests Passed: 43 (95.6%)
  Defects Found: 2
    - Critical: 0
    - High: 0
    - Medium: 1 (DEF-003)
    - Low: 1 (DEF-004)

Blockers:
  None / [Description if any]

Risks:
  None / [Description if any]

Next Actions:
  - Continue Dashboard testing
  - Follow up on DEF-003 fix
  - Begin UAT tomorrow

Questions:
  None / [Questions if any]

Approval: _________________ Date: _______
```

### Release Readiness Report
```
RELEASE READINESS ASSESSMENT
Project: HVAC Dashboard v2.0
Date: YYYY-MM-DD

Test Coverage: 98% (target: > 90%)
Pass Rate: 97% (target: > 95%)

Critical Issues: 0 ✓
High-Priority Issues: 0 ✓
Medium Issues: 1 (accepted risk)

Recommendation: ✓ APPROVED FOR RELEASE

Conditions:
  - Medium issue (DEF-007) has documented workaround
  - Monitoring active in production
  - Support team briefed

Approved By:
  QA Lead: _________________________ Date: _______
  PM: _________________________ Date: _______
  CTO: _________________________ Date: _______

Release Date: YYYY-MM-DD
Deployment Time: HH:MM AM/PM
Rollback Plan: [Procedure documented]
```

---

## Testing Best Practices Summary

### DO ✓
```
✓ Test according to specifications
✓ Document everything (test cases, results, evidence)
✓ Test both valid and invalid inputs
✓ Test error scenarios
✓ Test edge cases and boundaries
✓ Verify data after each operation
✓ Check error messages are helpful
✓ Test on multiple browsers/devices
✓ Test with real user scenarios
✓ Report issues clearly with steps to reproduce
✓ Ask questions if requirements unclear
✓ Stay organized and systematic
✓ Keep communication open with team
```

### DON'T ✗
```
✗ Skip steps in test cases
✗ Assume features work (test them)
✗ Only test the happy path
✗ Ignore small UI issues
✗ Forget to verify database changes
✗ Log vague defects ("it's broken")
✗ Leave console errors ignored
✗ Test on single browser only
✗ Report someone else's bugs as your own
✗ Go off-script without documenting
✗ Keep findings to yourself (communicate!)
✗ Merge multiple issues into one defect
✗ Delay reporting critical issues
```

---

## Testing Timeline Example

### Week 1: Functional + Security Testing
```
Monday:
  - Setup test environment
  - Prepare test data
  - Execute Dashboard tests (TC-F-001 to TC-F-010)

Tuesday:
  - Continue Navigation tests
  - Begin CRUD operations testing
  - Start security testing (auth/authz)

Wednesday:
  - Complete CRUD operations testing
  - Security testing (injection vulnerabilities)
  - Begin API testing

Thursday:
  - Complete API testing
  - Security testing (XSS, CSRF)
  - Begin performance baseline

Friday:
  - Complete security testing
  - Baseline performance report
  - Week 1 summary & debrief
```

### Week 2: Performance + Compatibility + UAT
```
Monday:
  - Load testing (50 users)
  - Browser compatibility testing
  - Continue CRUD regression

Tuesday:
  - Peak load testing (500 users)
  - Mobile device testing
  - Begin UAT

Wednesday:
  - Endurance test (start 24-hour run)
  - Complete compatibility testing
  - UAT workflows

Thursday:
  - Complete endurance test
  - Stress testing
  - UAT sign-offs

Friday:
  - Final regression
  - Release readiness report
  - Business sign-off
  - Deploy to staging/production
```

---

## Emergency Contacts

```
QA Lead: [Name] [Phone] [Email]
Development Lead: [Name] [Phone] [Email]
Security Lead: [Name] [Phone] [Email]
Project Manager: [Name] [Phone] [Email]
DevOps Lead: [Name] [Phone] [Email]
Business Owner: [Name] [Phone] [Email]

Slack Channel: #hvac-dashboard-testing
Escalation: [Process & contacts]
```

---

## Resources & Documentation

```
Testing Plan: hvac-comprehensive-testing-plan.xlsx
Execution Guide: TESTING-EXECUTION-GUIDE.md
Test Cases: [Link to test case repository]
Bug Tracking: [Jira/Linear/GitHub Issues URL]
Confluence/Wiki: [Internal documentation]
API Documentation: [Link to API docs]
```

---

## Final Reminders

✓ Quality is everyone's responsibility  
✓ Early defect detection saves money  
✓ Thorough testing builds confidence  
✓ Clear communication prevents surprises  
✓ Documented evidence proves thoroughness  
✓ Business user sign-off is essential  
✓ Monitor production after release  
✓ Continuous improvement from lessons learned  

**Happy Testing! 🚀**
